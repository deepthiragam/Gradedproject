package javaProject;

import java.util.Scanner;

public class AmountTransfer {
	Scanner sc=new Scanner(System.in);
	void Transfer() {
		System.out.println("Please Enter the account number for which the "
				+ "amount to be deposited: ");
		long Accnum=sc.nextLong();
		System.out.println("Enter the amount to be transfered: ");
		int Transfer=sc.nextInt();
		int balance=AccountNumber.bal;
		if(Transfer>balance) {
			System.out.println("Your account has insufficient funds");
		}
		else
			System.out.println("The amount "+Transfer+" has been "
					+ "successfully transfered to "+Accnum);
		int RemBal=balance-Transfer;
		System.out.println("After transferring your account has "+RemBal+" Rupees");
	}

}
