package javaProject;

import java.util.Scanner;

public class PerformWithdrawl {
	//AccountMenu a2=new AccountMenu();
	Scanner sc=new Scanner(System.in);
	void withdraw() {
		System.out.println("Please enter the amount to withdraw: ");
		int performWithdraw=sc.nextInt();
		int balance1=AccountNumber.bal;
		try {
		if(performWithdraw>balance1) {
			System.out.println("Your account has insufficient funds");
		}
		else
			System.out.println(performWithdraw+" has been withdrawn successfully from your account");
		}
		catch(Exception e) {
			System.out.println(e);
		}
		int RemainingBalance=balance1-performWithdraw;
		System.out.println("Your current balance is :"+RemainingBalance);
	}

}
