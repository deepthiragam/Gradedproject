package javaproject2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;


public class DataStructure2 implements Comparator<EmployeeDetails>{
	ArrayList<EmployeeDetails> employees;
	public void cityNameCount() {
		employees=new ArrayList<EmployeeDetails>();
		int i=1;
		employees.add(new EmployeeDetails(1,"Aman",  20,1100000,"IT",  "Delhi"));
		employees.add(new EmployeeDetails(2,"Bobby", 22,500000, "HR",  "Bombay"));
		employees.add(new EmployeeDetails(3,"Zeo",   20,750000, "Admin","Delhi"));
		employees.add(new EmployeeDetails(4,"Smitha",21,1000000,"IT",   "Chennai"));
		employees.add(new EmployeeDetails(5,"Smitha",24,1200000,"HR",   "Bangalore"));
		Collections.sort(employees,new DataStructure2());
		Iterator<EmployeeDetails> EmpIter1=employees.iterator();
		System.out.println();
		while(EmpIter1.hasNext()) {
			EmployeeDetails emp1=EmpIter1.next();
			System.out.println(emp1.city+":"+i);
				
			}
		}	
	@Override
	public int compare(EmployeeDetails cityName1, EmployeeDetails cityName2) {
		if(cityName1.city.compareTo(cityName2.city)>0) {
			return 1;
		}
		else if(cityName1.city.compareTo(cityName2.city)<0) {
			return -1;
	}
		else {
			return 0;
		}
	
	}
	
	}

	


