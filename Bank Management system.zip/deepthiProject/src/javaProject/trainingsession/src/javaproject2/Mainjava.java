package javaproject2;

import java.util.ArrayList;

public class Mainjava {
	public static void main(String[] args) {
		ArrayList<EmployeeDetails> employees;
		employees=new ArrayList<EmployeeDetails>();
		employees.add(new EmployeeDetails(1,"Aman",  20,1100000,"IT",  "Delhi"));
		employees.add(new EmployeeDetails(2,"Bobby", 22,500000, "HR",  "Bombay"));
		employees.add(new EmployeeDetails(3,"Zeo",   20,750000, "Admin","Delhi"));
		employees.add(new EmployeeDetails(4,"Smitha",21,1000000,"IT",   "Chennai"));
		employees.add(new EmployeeDetails(5,"Smitha",24,1200000,"HR",   "Bangalore"));
		System.out.println("List of Employees:-");
		for(int i=0;i<=employees.size()-1;i++) {
			System.out.println(employees.get(i));
		}
		System.out.println();
		DataStructure1 dsa=new DataStructure1();
		DataStructure2 dsb=new DataStructure2();
		DataStructure3 dsc=new DataStructure3();

		dsa.sortingNames();
		System.out.println();
		dsb.cityNameCount();
		System.out.println();
		dsc.monthlySalary();
		
	}

}
