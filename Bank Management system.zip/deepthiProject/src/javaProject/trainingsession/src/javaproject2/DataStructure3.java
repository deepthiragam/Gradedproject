package javaproject2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class DataStructure3 implements Comparator<EmployeeDetails>{
	public void monthlySalary() {
		ArrayList<EmployeeDetails> employees;
		employees=new ArrayList<EmployeeDetails>();
		employees.add(new EmployeeDetails(1,"Aman",  20,1100000,"IT",  "Delhi"));
		employees.add(new EmployeeDetails(2,"Bobby", 22,500000, "HR",  "Bombay"));
		employees.add(new EmployeeDetails(3,"Zeo",   20,750000, "Admin","Delhi"));
		employees.add(new EmployeeDetails(4,"Smitha",21,1000000,"IT",   "Chennai"));
		employees.add(new EmployeeDetails(5,"Smitha",24,1200000,"HR",   "Bangalore"));
		Collections.sort(employees,new DataStructure3());
		Iterator<EmployeeDetails> EmpIter2=employees.iterator();
		while(EmpIter2.hasNext()) {
			EmployeeDetails emp2=EmpIter2.next();
			System.out.println(emp2.id+" "+emp2.salary);
		}	
	}
	public int compare(EmployeeDetails empId1, EmployeeDetails empId2) {
		if(empId1.id>empId2.id) {
			return 1;
		}
		else if(empId1.id<empId2.id) {
			return -1;
		}
		else
			return 0;
	}
}
