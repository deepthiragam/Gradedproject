package javaproject2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class DataStructure1 implements Comparator<EmployeeDetails>{
	ArrayList<EmployeeDetails> employees;
	public void sortingNames() {
		employees=new ArrayList<EmployeeDetails>();
		employees.add(new EmployeeDetails(1,"Aman",  20,1100000,"IT",  "Delhi"));
		employees.add(new EmployeeDetails(2,"Bobby", 22,500000, "HR",  "Bombay"));
		employees.add(new EmployeeDetails(3,"Zeo",   20,750000, "Admin","Delhi"));
		employees.add(new EmployeeDetails(4,"Smitha",21,1000000,"IT",   "Chennai"));
		employees.add(new EmployeeDetails(5,"Smitha",24,1200000,"HR",   "Bangalore"));
		Collections.sort(employees,new DataStructure1());
		Iterator<EmployeeDetails> EmpIter=employees.iterator();
		while(EmpIter.hasNext()) {
			EmployeeDetails emp=EmpIter.next();
			System.out.print(emp.name+" ");
		}
	}
	@Override
	public int compare(EmployeeDetails empName1, EmployeeDetails empName2) {
		if(empName1.name.compareTo(empName2.name)>0) {
			return 1;
		}
		else if(empName1.name.compareTo(empName2.name)<0) {
			return -1;
		}
		else
			return 0;
		
	}

}
