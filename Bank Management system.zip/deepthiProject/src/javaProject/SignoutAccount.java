package javaProject;

public class SignoutAccount {
	void logout() {
		System.out.println("Your Account Has Been Successfully Logout");
		int rembalance=AccountNumber.bal;
		System.out.println("Current Balance:-"+rembalance);
		System.out.println("************THANK YOU**********");
	}

}
