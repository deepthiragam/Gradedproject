package javaProject;

import java.util.Scanner;

public class Deposite {
	Scanner sc=new Scanner(System.in);
	void deposit() {
	System.out.println("Enter the amount to deposit: ");
	int DepositAmount=sc.nextInt();
	System.out.println("Your amount has been successfully deposited");
	int balance=AccountNumber.bal;
	int currentbalance=DepositAmount+balance;
	System.out.println("Your current balance :"+currentbalance);
	}

}
