package javaProject;

import java.util.ArrayList;
import java.util.Scanner;

class AccountNumber {
	Scanner sc=new Scanner(System.in);
	static int bal=1000;
	Deposite pd=new Deposite();
	PerformWithdrawl pw=new PerformWithdrawl();
	AmountTransfer pt=new AmountTransfer();
	OtpGeneration po=new OtpGeneration();
	SignoutAccount lo=new SignoutAccount();
	int end;
	 int choice;	
	 void doProcess(){
do {
		System.out.println("Enter your choice: ");
		 choice=sc.nextInt();
		switch(choice) {
		case 1:
			pd.deposit();
			break;
		case 2:
			pw.withdraw();
			break;
		case 3:
			pt.Transfer();
			break;
		case 4:
			po.otpGenerate();
			break;
		case 5:
			lo.logout();
			break;
		default:
			if(choice>5) {
				System.out.println("enter a valid option");
				ArrayList<String> BankingOptions=new ArrayList<String>();
				BankingOptions.add("Deposit");
				BankingOptions.add("Withdrawal");
				BankingOptions.add("Transfer");
				BankingOptions.add("Otp generation");
				BankingOptions.add("LogOut");
			for(int i=0;i<=BankingOptions.size()-1;i++) {
				System.out.println(i+1+" : "+BankingOptions.get(i));
			}
			}
		
			}
		System.out.println("Enter 0 to go back");
		end=sc.nextInt();
		if(end==0)
			System.out.println("enter a valid option");
		ArrayList<String> BankingOptions=new ArrayList<String>();
		BankingOptions.add("Deposit");
		BankingOptions.add("Withdrawal");
		BankingOptions.add("Transfer");
		BankingOptions.add("Otp generation");
		BankingOptions.add("LogOut");
	for(int i=0;i<=BankingOptions.size()-1;i++) {
		System.out.println(i+1+" : "+BankingOptions.get(i));
	}
	doProcess();	
		}
while(end!=0);
	 }
}
	









