package javaProject;

import java.util.Scanner;

public class OtpGeneration {
	Scanner sc=new Scanner(System.in);
	void otpGenerate() {
		double otp;
		for(double counter=1000;counter<=9999;counter++) {
			otp=Math.random();
			double two=otp*10000;
			int one=(int)two;
			if(counter>1000) {
				break;
			}
			System.out.println("Dear customer your OTP is:- "+one);
		}
	
	}

}
