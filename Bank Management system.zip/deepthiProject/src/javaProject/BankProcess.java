package javaProject;

import java.util.ArrayList;
import java.util.Scanner;

public class BankProcess {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		AccountNumber a1=new AccountNumber();
		System.out.println("--------------------Namasthe--------------------");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your account number:");
		final long Account_number=sc.nextLong();
		System.out.println("Enter your account password:");
		final String password=sc.next();
		System.out.println("Enter Your Choice :");
		ArrayList<String> BankingOptions=new ArrayList<>();
			BankingOptions.add("Deposit");
			BankingOptions.add("Withdrawal");
			BankingOptions.add("Transfer");
			BankingOptions.add("Otp generation");
			BankingOptions.add("LogOut");
		for(int i=0;i<=BankingOptions.size()-1;i++) {
			System.out.println(i+1+" : "+BankingOptions.get(i));
		}
		a1.doProcess();
		sc.close();
		}	
	}
	


