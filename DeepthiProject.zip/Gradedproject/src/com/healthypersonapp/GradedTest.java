package com.healthypersonapp;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class GradedTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void  should_ReturnTrue_When_DietRecommended() {
		assertEquals(BMICalculator.isDietRecommended(1000.0,5.0),true);
	}
	@Test
	public void should_ReturnFalse_When_DietNotRecommended() {
		assertEquals(BMICalculator.isDietRecommended(100.0,5.0),false);
	}
	@SuppressWarnings("deprecation")
	
	@Rule
	public ExpectedException thrown=ExpectedException.none();
	@Test
	public void should_ThrowArithmeticException_When_HeightZero() {
		thrown.expect(ArithmeticException.class);
		thrown.expectMessage("Arithmetic Exception");
		BMICalculator.isDietRecommended(10000,0);}
//	@Test
//	public void  should_ReturnPersonWithWorstBMI_When_PersonListNotEmpty() {
//		assertEquals(BMICalculator.findPersonWithWorstBMI(null));
//	}
//	
	

}
