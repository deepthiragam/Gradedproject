package com.project.bookshop;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.project.bookshop.Book;
public class BookStore {
	public static void main(String[] args) {
	Book student1=new Book(1,"To Kill a MockingBird",200,"Classics");
	Book student2=new Book(2,"Carrie",1000,"Horror");
	Book student3=new Book(3,"The Savior",150,"Romance");
	Book student4=new Book(4,"Wings of Fire",250,"Autobiography");
	Book student5=new Book(5,"Gandhi",250,"Autobiography");
	Book student6=new Book(6,"The Martain",1000,"Sci-fi");
	Book student7=new Book(7,"Animal Form",200,"Political Satire");
	Book student8=new Book(8,"Think and Grow Rich",500,"Self-Help");
	Book student9=new Book(9,"Can't Hurt Me",2000,"Motivation");
	Book student10=new Book(10,"Getting Things Done",350,"Self-Help");
	List<Book> bookDetails=new ArrayList<>();
	bookDetails.add(student1);
	bookDetails.add(student2);
	bookDetails.add(student3);
	bookDetails.add(student4);
	bookDetails.add(student5);
	bookDetails.add(student6);
	bookDetails.add(student7);
	bookDetails.add(student8);
	bookDetails.add(student9);
	bookDetails.add(student10);
	bookDetails.forEach((bookList)->System.out.println( "Id-> "+bookList.getId()+" Name->"+bookList.getName()
	+" Price->"+bookList.getPrice()+" Genre->"+bookList.getGenre()));
	double average=bookDetails.stream()
			.mapToInt(bookList->bookList.getPrice())
			.average()
			.getAsDouble();
	System.out.println("The average price of all the books in bookstore is -->"+average);
	long count=bookDetails.stream().count();
	System.out.println("Total no of books in the library -->"+count);
	System.out.println("Autobiographies-->"+bookDetails.stream()
			.filter(bookList->bookList.getGenre().equals("Autobiography"))
			.map(bookList->bookList.getName())
			.collect(Collectors.toList()));
	long distinctGenres=bookDetails.stream()
			.map(bookList->bookList.getGenre())
			.distinct()
			.count();
	System.out.println("Count of distinct genre is-->"+distinctGenres);
	}
}

