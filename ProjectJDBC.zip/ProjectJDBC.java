package com.gl.pro;

import java.sql.*;

public class ProjectJDBC {
  public static void main(String[] args) {
    String url = "jdbc:mysql://localhost:3306/gradedProject2";
    String user = "root";
    String password = "admin";

    try {
      Connection con = DriverManager.getConnection(url, user, password);

      String query = "INSERT INTO employee (Id, Name, Email_Id, Phone_Number) VALUES (?, ?, ?, ?)";

      PreparedStatement pstmt = con.prepareStatement(query);

      // Insert 5 records
      
      pstmt.setInt(1, 1);
      pstmt.setString(2, "Andraoy");
      pstmt.setString(3, "androy@example.com");
      pstmt.setString(4, "8855776690");
      pstmt.executeUpdate();

      pstmt.setInt(1, 2);
      pstmt.setString(2, "Blessy");
      pstmt.setString(3, "blessy@example.com");
      pstmt.setString(4, "2345678901");
      pstmt.executeUpdate();

      pstmt.setInt(1, 3);
      pstmt.setString(2, "Nissy");
      pstmt.setString(3, "nissy@example.com");
      pstmt.setString(4, "6677880042");
      pstmt.executeUpdate();

      pstmt.setInt(1, 4);
      pstmt.setString(2, "Jessy");
      pstmt.setString(3, "jessy@example.com");
      pstmt.setString(4, "3344990665");
      pstmt.executeUpdate();

      pstmt.setInt(1, 5);
      pstmt.setString(2, "Roy");
      pstmt.setString(3, "roy@example.com");
      pstmt.setString(4, "6644885590");
      pstmt.executeUpdate();
      
//    Modify Email_Id column to varchar(30) NOT NULL
      
      System.out.println("Records inserted successfully.");
      String query1 = "ALTER TABLE employee MODIFY Email_Id VARCHAR(30) NOT NULL";
      Statement stmt = con.createStatement();
      stmt.executeUpdate(query1);
      System.out.println("Column modified successfully.");
      String query2 = "INSERT INTO employee (Id, Name, Email_Id, Phone_Number) VALUES (?, ?, ?, ?)";

      PreparedStatement pstmt1 = con.prepareStatement(query2);

//    Insert 2 records
      
      pstmt.setInt(1, 6);
      pstmt.setString(2, "Lusifer");
      pstmt.setString(3, "lusi@example.com");
      pstmt.setString(4, "6789012345");
      pstmt.executeUpdate();

      pstmt.setInt(1, 7);
      pstmt.setString(2, "John Wesly");
      pstmt.setString(3, "john@example.com");
      pstmt.setString(4, "8866443366");
      pstmt.executeUpdate();
      
      
//	   Update the name of employee Id 3 to Karthik and phone number to 1234567890.
      
      System.out.println("Records inserted successfully.");
      
      String query3 = "UPDATE employee SET Name=?, Phone_Number=? WHERE Id=?";

      PreparedStatement pstmt3 = con.prepareStatement(query3);

      pstmt3.setString(1, "Kiran");
      pstmt3.setString(2, "12345995544");
      pstmt3.setInt(3, 3);
      
      int rowsUpdated = pstmt3.executeUpdate();

      if (rowsUpdated > 0) {
        System.out.println("Employee record updated successfully.");
      } else {
        System.out.println("No employee record found for the given Id.");
      }
      
      //Delete employee records 3 and 4.
      
      String query4 = "DELETE FROM employee WHERE Id IN (?, ?)";

      PreparedStatement pstmt4 = con.prepareStatement(query4);

      pstmt4.setInt(1, 3);
      pstmt4.setInt(2, 4);

      int rowsDeleted = pstmt4.executeUpdate();

      if (rowsDeleted > 0) {
        System.out.println(rowsDeleted + " employee records deleted successfully.");
      } else {
        System.out.println("No employee records found for the given Ids.");
      }
      
      //Remove all records from the table employee.
      
      String query5 = "DELETE FROM employee";

      PreparedStatement pstmt5 = con.prepareStatement(query5);

      int rowsDeleted1 = pstmt5.executeUpdate();

      if (rowsDeleted1 > 0) {
        System.out.println(rowsDeleted1 + " employee records deleted successfully.");
      } else {
        System.out.println("No employee records found.");
      }



      pstmt.close();
      con.close();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
  
}

